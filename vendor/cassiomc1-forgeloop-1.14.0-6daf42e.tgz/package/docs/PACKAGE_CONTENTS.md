# Core npm package contents

This page describes the intentional boundary of the privately delivered
`@cassiomc1/forgeloop` package. The [`files`](../package.json) list in
`package.json` is the packaging source of truth, while the repository's
`tests/package.test.js` and clean-room `scripts/package_smoke.mjs` checks keep
the boundary executable. Those test files are repository tooling and are not
part of the consumer tarball.

## Consumer surface

The package exposes the `forgeloop` executable from `src/cli.js` and the
`@cassiomc1/forgeloop/integration` subpath from `src/integration.js`, with its
declaration file. The package has the approved exact `@typesafe-ai/sdk`
dependency for the pinned semantic decision plane and `smol-toml` for bounded
Cargo manifest parsing. It requires Node.js 20 or newer.

## Included files

The public package includes the Jev decision-plane documentation and bounded
diagnostic scripts:

- `docs/JEV_BENCHMARKS.md`
- `docs/MODEL_ROUTING.md`
- `docs/SEMANTIC_DECISION_PLANE.md`
- `docs/TEST_INTELLIGENCE.md`
- `docs/TEST_PRUNING.md`
- `scripts/jev-smoke.mjs`
- `scripts/benchmark-jev.mjs`
- `scripts/benchmark-test-intelligence.mjs`
- `schemas/context-plan.schema.json`
- `schemas/semantic-decision.schema.json`
- `schemas/test-utility.schema.json`

The published tarball includes the following consumer-facing groups:

- **Runtime and protocol:** every maintained JavaScript module under `src/`,
  the guide registry, protocol templates, JSON schemas, completions, and the
  generic CI verifier. Four retired compatibility helpers remain in the
  repository for historical context and are explicitly excluded:
  `src/core/cli-metadata.js`, `src/core/decision-classification.js`,
  `src/core/gates.js`, and `src/core/workflow-compatibility.js`.
  This includes the provider-neutral Repository Index runtime and its pinned
  `src/repository-index/tgrep-manifest.json`; native engine binaries are
  provisioned outside the npm tarball.
- **Specialist guidance:** every registered consumer guide under `ENG/`,
  including `ENG/flutter-development-eng.md`,
  `ENG/dotnet-aspnetcore-development-eng.md`,
  `ENG/nodejs-backend-development-eng.md`,
  `ENG/rust-development-eng.md`, and the C, C++, Java, SQL, Go, TypeScript,
  PHP, and Swift specialists, ships with the guide registry and is resolved
  from package-local paths. Specialists are selected only from their bounded
  structural primary evidence; SQL remains a scoped host-project overlay.
  ASP.NET Core and ABP are conditional routing overlays on the `dotnet` guide,
  not additional package guides. The package does not install or invoke
  framework, compiler, build, package-manager, or database tooling.
- **Initialization material:** the root protocol and integration documents,
  third-party notices, the target profile template, and every path listed by
  `src/core/templates.js`. These files are read by `init` and `update`, so
  they are part of the executable consumer contract even when a document is
  marked deprecated in the documentation manifest.
- **Benchmark inputs:** execution-profile scenario definitions and their
  README. They make new measurements reproducible; historical measurements
  and generated results are repository evidence and are excluded.
  Repository Index query inputs and benchmark instructions are also shipped;
  generated local repositories and measurements are not.
- **User documentation:** the getting-started, integration, CLI, artifact,
  Repository Index, Persistent Search Transport, troubleshooting, release,
  package-boundary, and related reference pages, together with the
  machine-readable documentation and protocol indexes and `CONTRIBUTING.md`.
   The advisory-context, Ripwire, OpenSrc, Agent Browser, and Audit UX guides ship with
   the corresponding public integration surface.
   Provider architecture, provider reference, and Security Review provider
   documentation are also packaged.
   The generated portable ForgeLoop Agent Skill and `docs/AGENT_SKILL.md` are
   packaged as instruction/documentation content, not runtime authority.
  Provider implementation modules ship under `src/`, but packaged source file
  does not mean a supported public import path; the generic `./providers`
  subpath remains unexported.
  The lifecycle recovery surface includes the explicit `task-abandon` command;
  it releases validated claims without asserting completion or publication.
  The typed diagram sources, generated HTML/SVG/receipt artifacts, and
  source-bound review records under `docs/diagrams/` are included together so
  the packaged documentation keeps its visual provenance.
- **Release tooling:** the selected deterministic generators, validators,
  benchmark helpers, and shell completions needed by maintainers who consume
  the source kit.

## Excluded files

The tarball intentionally omits repository-only material:

- tests, conformance fixtures, coverage output, and secret-scanning helpers;
  Harness-specific Agent Skill installation directories and Skill caches are
  not packaged.
- local `.forgeloop` state, task ledgers, locks, transactions, and execution
  receipts; the target `.forgeloop/.gitignore` is generated from an inline
  runtime template and no `.forgeloop/*` files are packaged;
- raw or aggregate benchmark results, package archives, and release train
  contracts;
- the Ripwire retrieval benchmark runner, cases, and fixture corpus; those
  maintainer-only files require a clean repository checkout and are not part of
  the consumer adapter surface;
- historical release plans and retired MCP adapter sources; the MCP adapter
  is published as its own package;
- the repository-only README hero assets
  `docs/assets/forgeloop-architecture.svg` and
  `docs/assets/forgeloop-lifecycle-animated.svg`. They are referenced by the
  repository README and are intentionally outside the core tarball.
- the execution PoC, its audit, and its evidence package. Packaged README and
  index links to this repository-only material use GitHub URLs so they remain
  truthful for npm consumers.

The package test checks all registered guide paths and these exclusion classes. It
also enumerates `src/**/*.js` and fails if a maintained runtime module is
missing from the candidate tarball or if a retired helper is reintroduced.
The repository index remains a catalog: links from `DOCS_INDEX.md` to tests,
historical plans, and source trees may intentionally resolve only in the full
repository and are not package dependencies. The canonical documentation and
protocol indexes are included in the tarball.

## Verification and publication

Run the following checks from a clean checkout before opening a release PR:

```bash
npm pack --dry-run --json
npm run pack:check
npm run pack:smoke
```

`pack:smoke` installs the candidate tarball into a temporary consumer and
exercises the CLI, public Integration API, initialization, schemas, and the
Structural Quality documentation's packaged diagram references. The
package-boundary tests also assert
that every registered guide path, including all language specialists, is
present in the candidate. The manual, explicitly authorized publication workflow runs the same smoke
gate before `npm publish --provenance --access restricted`.
Publication therefore remains owned by the authorized manual GitHub Actions
workflow and uses restricted npm access; local package inspection proves the
candidate boundary but does not publish it.
