import {
  FORGELOOP_INTEGRATION_RUNTIME_VERSION,
  executeForgeLoopCommand,
} from "./core/command-runtime.js";
import { validateForgeLoopCommandInput, defaultCommandInputValues } from "./core/command-input.js";
import { CLI_COMMAND_DEFINITIONS } from "./core/cli-command-definitions.js";
import {
  INTEGRATION_RISK_CLASSES,
  classifyForgeLoopInvocation,
  getForgeLoopCapabilities,
} from "./core/integration-invocation-policy.js";
import { readForgeLoopIntegrationResource, INTEGRATION_RESOURCE_DEFINITIONS } from "./core/integration-resources.js";
import { resolveForgeLoopProjectRoot } from "./core/project-root.js";
import { INTEGRATION_LIMITS } from "./core/integration-limits.js";
import { AUDIT_UX_CATEGORIES, AUDIT_UX_LIMITS, AUDIT_UX_SCHEMA_VERSION } from "./core/audit-ux.js";
import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

/**
 * Version of the installed @cassiomc1/forgeloop package providing this
 * integration API (closing plan §14-16): lets external adapters report the
 * real core version without hardcoding or deep-importing package internals.
 */
export function getForgeLoopPackageVersion() {
  const packageJsonPath = path.join(
    path.dirname(fileURLToPath(import.meta.url)),
    "..",
    "package.json",
  );
  return JSON.parse(readFileSync(packageJsonPath, "utf8")).version;
}

export {
  FORGELOOP_INTEGRATION_RUNTIME_VERSION,
  executeForgeLoopCommand,
  validateForgeLoopCommandInput,
  defaultCommandInputValues,
  getForgeLoopCapabilities,
  classifyForgeLoopInvocation,
  readForgeLoopIntegrationResource,
  resolveForgeLoopProjectRoot,
  INTEGRATION_LIMITS,
  AUDIT_UX_CATEGORIES,
  AUDIT_UX_LIMITS,
  AUDIT_UX_SCHEMA_VERSION,
  INTEGRATION_RISK_CLASSES,
  INTEGRATION_RESOURCE_DEFINITIONS,
  CLI_COMMAND_DEFINITIONS,
};

export { createForgeLoopContext } from "./core/runtime-context.js";
export { searchRepository } from "./repository-index/search.js";
export { getRepositoryIndexStatus } from "./repository-index/status.js";
export {
  rebuildRepositoryIndex,
  restartRepositoryIndexServer,
  setupRepositoryIndex,
  startRepositoryIndexServer,
  stopRepositoryIndexServer,
} from "./repository-index/server.js";

/** Stable Integration API operation for provider-neutral repository search. */
export async function repositorySearch({ projectPath = ".", ...request } = {}) {
  const { searchRepository } = await import("./repository-index/search.js");
  return searchRepository(projectPath, request);
}

/** Stable read-only Integration API projection for repository-index health. */
export async function repositoryIndexStatus({ projectPath = ".", ...options } = {}) {
  const { getRepositoryIndexStatus } = await import("./repository-index/status.js");
  return getRepositoryIndexStatus(projectPath, options);
}
export {
  assertStructuralQualityProvider,
  createStructuralQualityProviderRegistry,
  normalizeStructuralQualityDetection,
  normalizeStructuralQualitySnapshot,
  resolveStructuralQualityProvider,
} from "./core/structural-quality/provider.js";
export {
  STRUCTURAL_QUALITY_CHECK_ID,
  STRUCTURAL_QUALITY_MODES,
  STRUCTURAL_QUALITY_REQUIREMENT,
  STRUCTURAL_QUALITY_ROOT_CAUSES,
  STRUCTURAL_QUALITY_STATUSES,
} from "./core/structural-quality/constants.js";
export {
  PROFILE_CONTEXT_POLICIES,
  buildExecutionProfileContext,
  getExecutionProfileContextPolicy,
  legacyExecutionProfile,
  projectExecutionProfileContext,
} from "./core/execution-profile-context.js";
export {
  EXECUTION_PROFILES,
  EXECUTION_PROFILE_REQUESTS,
  LEGACY_EXECUTION_PROFILE,
  projectExecutionProfile,
  resolveExecutionProfile,
} from "./core/execution-profile.js";
export {
  E_VERIFICATION_EXECUTION_INVALID,
  E_VERIFICATION_ISOLATION_UNAVAILABLE,
  VERIFICATION_EXECUTION_POLICY_MODES,
  VERIFICATION_ISOLATION_MODES,
} from "./core/verification-execution.js";
export { recallAdvisoryContext } from "./core/advisory-context/service.js";
export { runBrowserVerification } from "./core/browser-verification/service.js";
export {
  BROWSER_VERIFICATION_ASSERTION_KINDS,
  BROWSER_VERIFICATION_ASSERTION_STATUSES,
  BROWSER_VERIFICATION_CAPTURE_POLICIES,
  BROWSER_VERIFICATION_LIMITS,
  BROWSER_VERIFICATION_LOCATOR_KINDS,
  BROWSER_VERIFICATION_STEP_KINDS,
  BROWSER_VERIFICATION_TRUST,
  BROWSER_VERIFICATION_WAIT_CONDITIONS,
  normalizeBrowserVerificationRequestOptions,
} from "./core/browser-verification/constants.js";
export {
  assertBrowserVerificationProvider,
  assertBrowserVerificationProviderIdentity,
  assertBrowserVerificationProviderRegistration,
  BROWSER_VERIFICATION_PROVIDER_ID_PATTERN,
  createBrowserVerificationProviderRegistry,
  normalizeBrowserVerificationRequest,
  resolveBrowserVerificationProvider,
} from "./core/browser-verification/provider.js";
export { normalizeBrowserVerificationResult } from "./core/browser-verification/normalize.js";
export { runSecurityReview } from "./core/security-review/service.js";
export {
  SECURITY_REVIEW_CATEGORIES,
  SECURITY_REVIEW_CONFIDENCE,
  SECURITY_REVIEW_LIMITS,
  SECURITY_REVIEW_SCOPES,
  SECURITY_REVIEW_SEVERITIES,
  SECURITY_REVIEW_TRUST,
} from "./core/security-review/constants.js";
export {
  SECURITY_REVIEW_PROVIDER_ID_PATTERN,
  assertSecurityReviewProvider,
  assertSecurityReviewProviderIdentity,
  assertSecurityReviewProviderRegistration,
  createSecurityReviewProviderRegistry,
  normalizeSecurityReviewRequest,
  resolveSecurityReviewProvider,
} from "./core/security-review/provider.js";
export { normalizeSecurityReviewResult } from "./core/security-review/normalize.js";
export { createRipwireAdvisoryContextProvider } from "./adapters/ripwire/provider.js";
export { createOpenSrcAdvisoryContextProvider } from "./adapters/opensrc/provider.js";
export { createAgentBrowserVerificationProvider } from "./adapters/agent-browser/provider.js";
export {
  createEmulatedServicesProvider,
  EMULATED_SERVICES_ERROR_CODES,
  EMULATED_SERVICES_ID,
  EMULATED_SERVICES_PROCESS_LIMITS,
  EMULATED_SERVICES_SUPPORTED_VERSION,
} from "./adapters/emulated-services/index.js";
export {
  ADVISORY_CONTEXT_LIMITS,
  ADVISORY_CONTEXT_TRUST,
  normalizeAdvisoryRecallOptions,
} from "./core/advisory-context/constants.js";
export {
  assertAdvisoryContextProvider,
  assertAdvisoryContextProviderIdentity,
  createAdvisoryContextProviderRegistry,
  normalizeAdvisoryContextResult,
  resolveAdvisoryContextProvider,
} from "./core/advisory-context/provider.js";
export {
  normalizePortableText,
  assertPortableContextSafe,
  PortableContextError,
} from "./core/portable-context.js";
export {
  acceptCanonicalHandoff,
  resolveHandoffAcceptance,
} from "./core/handoff-acceptance.js";

export const FORGELOOP_INTEGRATION_API_VERSION = FORGELOOP_INTEGRATION_RUNTIME_VERSION;
