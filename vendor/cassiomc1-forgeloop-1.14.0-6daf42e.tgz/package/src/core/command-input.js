import { continuityOptionDefaults, validateContinuityOptions } from "./continuity-cli-options.js";
import { E_CLI_INVOCATION_INVALID } from "./error-codes.js";
import { EXECUTION_PROFILE_REQUESTS } from "./execution-profile.js";

function inputError(message) {
  const error = new Error(message);
  error.code = E_CLI_INVOCATION_INVALID;
  return error;
}

function validateSearchCommandInput(command, options, help) {
  if (command === "search" && !help && (typeof options.pattern !== "string" || options.pattern.length === 0)) {
    throw inputError("search requires a pattern");
  }
}

function validatePolicyInput(command, options) {
  if (command === "policy" && !options.policy) throw inputError("policy requires a name");
  if (command !== "policy" && options.policy) throw inputError(`Policy name is not valid for ${command}`);
}

function validateContractBootstrapRepairMigrationInput(command, options) {
  if (command !== "task-migrate-contract-bootstrap-repair") return;
  if (!options.taskId) throw inputError("task-migrate-contract-bootstrap-repair requires --task");
  if (!options.acknowledgeMigration) throw inputError("task-migrate-contract-bootstrap-repair requires --acknowledge-migration");
}

function validateTaskCreationInput(command, options, help = false) {
  if (help) return;
  if (command === "bundle" && !options.taskId) throw inputError("bundle requires --task");
  if (command === "task-create" && !options.taskId) throw inputError("task-create requires --task");
  if (!["task-create", "contract-create", "contract-revise"].includes(command) && (options.preset || options.preview)) {
    throw inputError(`preset/preview options are not valid for ${command}`);
  }
  if (command === "task-create" && options.preview && !options.preset && !options.contractFile) {
    throw inputError("task-create --preview requires --preset or --contract-file");
  }
  if (command === "task-create" && options.preset && options.contractFile) {
    throw inputError("task-create accepts either --preset or --contract-file, not both");
  }
  if (command === "contract-create" && !options.taskId) throw inputError("contract-create requires --task");
  if (command === "contract-create" && !options.preset && !options.contractFile) throw inputError("contract-create requires --preset or --contract-file");
  if (command === "contract-create" && options.preset && options.contractFile) throw inputError("contract-create accepts either --preset or --contract-file, not both");
  if (command === "contract-revise" && !options.taskId) throw inputError("contract-revise requires --task");
  if (command === "contract-revise" && !options.preset && !options.contractFile) throw inputError("contract-revise requires --preset or --contract-file");
  if (command === "contract-revise" && options.preset && options.contractFile) throw inputError("contract-revise accepts either --preset or --contract-file, not both");
  if (command === "task-repair-contract-bootstrap" && !options.taskId) throw inputError("task-repair-contract-bootstrap requires --task");
  if (command === "task-repair-contract-bootstrap" && !options.acknowledgeRepair) throw inputError("task-repair-contract-bootstrap requires --acknowledge-repair");
  validateContractBootstrapRepairMigrationInput(command, options);
  const hasTaskListFilter = Boolean(
    options.phase
      || options.active
      || (options.limit !== undefined && options.limit !== null)
      || (options.offset !== undefined && options.offset !== null && options.offset !== 0),
  );
  if (command !== "task-list" && hasTaskListFilter) {
    throw inputError(`task-list filters are not valid for ${command}`);
  }
}

function validateGateRecordInput(command, options, help) {
  if (command !== "gate-record" || help) return;
  if (!options.taskId) throw inputError("gate-record requires --task");
  if (!options.gate) throw inputError("gate-record requires --gate");
  if (!["satisfied", "unverified", "blocked"].includes(options.gateStatus)) {
    throw inputError("gate-record --status must be satisfied, unverified, or blocked");
  }
}

function validateExecutionProfileInput(command, options) {
  if (options.executionProfile !== null && options.executionProfile !== undefined) {
    if (command !== "route") throw inputError(`executionProfile is not valid for ${command}`);
    if (!EXECUTION_PROFILE_REQUESTS.includes(options.executionProfile)) {
      throw inputError(`route --execution-profile must be one of ${EXECUTION_PROFILE_REQUESTS.join(", ")}`);
    }
  }
}

function validateUsageInput(command, options, help) {
  if (command === "usage-record" && !help) {
    if (!options.taskId) throw inputError("usage-record requires --task");
    if ((options.usageSource ?? "ACTOR_REPORTED") !== "ACTOR_REPORTED") {
      throw inputError("usage-record accepts only --source ACTOR_REPORTED");
    }
  }
  if (command === "efficiency" && !help && !options.taskId) {
    throw inputError("efficiency requires --task");
  }
}

function validateQualityInput(command, options, help) {
  if (["quality-baseline", "quality-verify", "quality-status"].includes(command) && !help && !options.taskId) {
    throw inputError(`${command} requires --task`);
  }
  if (["quality-baseline", "quality-verify"].includes(command) && !help
    && options.timeoutMs !== null && options.timeoutMs !== undefined
    && (!Number.isInteger(options.timeoutMs) || options.timeoutMs < 0 || options.timeoutMs > 300000)) {
    throw inputError(`${command} --timeout-ms must be between 0 and 300000`);
  }
}

function validateProfileAndUsageInput(command, options, help) {
  validateExecutionProfileInput(command, options);
  validateUsageInput(command, options, help);
  validateQualityInput(command, options, help);
  if (command !== "quality-baseline" && options.replace === true) throw inputError("--replace is only valid for quality-baseline");
  if (command !== "usage-record" && options.usageSource !== undefined && options.usageSource !== "ACTOR_REPORTED") {
    throw inputError(`usageSource is not valid for ${command}`);
  }
}

function validateOutputInput(command, options) {
  if (options.compact === true && !["next", "task-show"].includes(command)) {
    throw inputError(`compact output is not valid for ${command}`);
  }
  if (command !== "next" && options.explain === true) throw inputError(`explain output is not valid for ${command}`);
}

const TASK_SELECTOR_COMMANDS = new Set([
  "context-plan",
  "model-route",
  "semantic-plan",
  "test-utility",
  "checkpoint-revalidate",
  "workspace-bind",
  "workspace-status",
  "handoff-create",
  "handoff-list",
  "handoff-show",
  "handoff-accept",
  "responsibility-set",
  "responsibility-status",
  "verify-scope",
  "attestation-create",
  "attestation-status",
  "attestation-verify",
]);

function validateRequiredTaskSelector(command, options, help) {
  if (TASK_SELECTOR_COMMANDS.has(command) && !help && !options.taskId) {
    throw inputError(`${command} requires --task`);
  }
}

function validateHandoffShowInput(command, options, help) {
  if (command === "handoff-show" && !help && !options.handoffId) throw inputError("handoff-show requires --id");
}

function validateHandoffAcceptInput(command, options, help) {
  if (command !== "handoff-accept" || help) return;
  if (!options.handoffId) throw inputError("handoff-accept requires --handoff");
  if (!options.consumerId) throw inputError("handoff-accept requires --consumer-id");
}

function validateResponsibilityInput(command, options, help) {
  if (command === "responsibility-set" && !help && !options.responsibilityLabel) {
    throw inputError("responsibility-set requires --label");
  }
}

function validateVerificationScopeInput(command, options, help) {
  if (command !== "verify-scope" || help) return;
  const mode = String(options.verificationScopeMode ?? "AUTO").toUpperCase();
  if (!["AUTO", "CHANGED", "CLAIMED", "FULL"].includes(mode)) throw inputError("verify-scope --mode must be AUTO, CHANGED, CLAIMED, or FULL");
}

function validateAttestationRangeInput(command, options, help) {
  if (command !== "attestation-verify-range" || help) return;
  if (!options.baseRevision) throw inputError("attestation-verify-range requires --base");
  if (!options.headRevision) throw inputError("attestation-verify-range requires --head");
}

function validateTaskSelectorsInput(command, options, help) {
  validateRequiredTaskSelector(command, options, help);
  validateHandoffShowInput(command, options, help);
  validateHandoffAcceptInput(command, options, help);
  validateResponsibilityInput(command, options, help);
  validateVerificationScopeInput(command, options, help);
  validateAttestationRangeInput(command, options, help);
}

function validateRecordCheckInput(options) {
  if (!options.checkId) throw inputError("record-check requires --id");
  if (!options.checkRequirement) throw inputError("record-check requires --requirement");
  if (!options.checkStatus) throw inputError("record-check requires --status");
  if (!options.checkEvidenceKind) throw inputError("record-check requires --evidence-kind");
  if (!options.checkCommand && !options.checkResult) throw inputError("record-check requires --command or --result");
}

function validateCommandCheckInput(options, command) {
  if (!options.checkId) throw inputError(`${command} requires --id`);
  if (!options.checkRequirement) throw inputError(`${command} requires --requirement`);
  if (options.checkKind || options.checkStatus || options.checkEvidenceKind || options.checkCommand
    || options.checkResult || options.checkExitCode !== null || options.checkExecutionRef || options.checkProvenance) {
    throw inputError(`${command} accepts only --id, --requirement, --details,${command === "run-check" ? " --timeout-ms, --scope-ref," : ""} and -- <argv>`);
  }
  if (!Array.isArray(options.commandArgv) || options.commandArgv.length === 0) throw inputError(`${command} requires -- followed by an exact command argv`);
}

function validateCheckInput(command, options, help) {
  if (help) return;
  if (command === "record-check") validateRecordCheckInput(options);
  if (command === "run-check" || command === "reconcile-closure") validateCommandCheckInput(options, command);
}

/**
 * Transport-neutral option defaults shared by the CLI parser and the
 * programmatic command runtime so every executor observes the same
 * normalized input shape regardless of transport.
 */
export function defaultCommandInputValues() {
  return {
    path: ".",
    dryRun: false,
    json: false,
    compact: false,
    explain: false,
    strict: false,
    fix: false,
    adopt: [],
    pattern: null,
    globs: [],
    types: [],
    fixedStrings: false,
    ignoreCase: false,
    smartCase: false,
    wordRegexp: false,
    context: null,
    beforeContext: null,
    afterContext: null,
    maxCount: null,
    filesWithMatches: false,
    stats: false,
    assetPath: null,
    binaryPath: null,
    force: false,
    acknowledgeRepair: false,
    acknowledgeMigration: false,
    workType: null,
    surfaces: [],
    risks: [],
    platforms: [],
    behaviorChange: false,
    executableChange: false,
    executionProfile: null,
    usageProvider: null,
    usageModel: null,
    usageInputTokens: null,
    usageOutputTokens: null,
    usageCacheReadTokens: null,
    usageCacheWriteTokens: null,
    usageTotalTokens: null,
    usageCostUsd: null,
    usageSource: "ACTOR_REPORTED",
    baselinePath: null,
    to: null,
    file: null,
    contractFile: null,
    preset: null,
    gate: null,
    gateStatus: null,
    gateArtifacts: [],
    gateDecisions: [],
    gateUnknowns: [],
    gateAssumptions: [],
    gateEvidenceFile: null,
    preview: false,
    phase: null,
    active: false,
    limit: null,
    offset: 0,
    routeFile: null,
    stateFile: null,
    receiptFile: null,
    continuityFile: null,
    taskBriefFiles: [],
    delegatedResultFiles: [],
    checkId: null,
    checkKind: null,
    checkRequirement: null,
    checkStatus: null,
    checkEvidenceKind: null,
    checkCommand: null,
    checkResult: null,
    checkExitCode: null,
    checkDetails: null,
    checkExecutionRef: null,
    checkProvenance: null,
    timeoutMs: null,
    replace: false,
    scopeRef: null,
    commandArgv: [],
    checkType: null,
    checkSource: null,
    policy: null,
    taskId: null,
    recipientHint: null,
    handoffNote: null,
    handoffId: null,
    consumerId: null,
    harness: null,
    responsibilityLabel: null,
    responsibilityAllowedPaths: [],
    responsibilityReadOnlyPaths: [],
    responsibilityRequiredChecks: [],
    responsibilityFreezeContract: false,
    responsibilityFreezeRoute: false,
    responsibilityFreezeClaims: false,
    verificationScopeMode: null,
    revisionProvider: null,
    signingProvider: null,
    trustedRoot: null,
    baseRevision: null,
    headRevision: null,
    requireCompleteCoverage: false,
    requireSignature: false,
    attestationRef: null,
    attestationBundle: null,
    attestationIdentity: null,
    attestationIssuer: null,
    help: false,
    version: false,
    ...continuityOptionDefaults(),
  };
}

/**
 * Canonical semantic validation shared by the CLI argv parser and
 * programmatic integrations. JSON-Schema style checks cannot express these
 * cross-field rules, so every transport must run this after its own parsing.
 */
export function validateForgeLoopCommandInput({ command, input, help = false } = {}) {
  const options = input ?? {};
  if (!command) return;

  validatePolicyInput(command, options);
  validateTaskCreationInput(command, options, help);
  validateGateRecordInput(command, options, help);
  validateSearchCommandInput(command, options, help);
  validateProfileAndUsageInput(command, options, help);
  validateOutputInput(command, options);
  validateTaskSelectorsInput(command, options, help);

  validateContinuityOptions(command, options);

  validateCheckInput(command, options, help);
}
