import { GUIDE_IDS, PROTOCOL_VERSION } from "./protocol.js";
import { assertExecutionProfile, resolveExecutionProfile } from "./execution-profile.js";
import { PROJECT_EVIDENCE_SCOPES } from "./project-detection.js";

export const ROUTING_SCHEMA_VERSION = 1;

const WORK_TYPES = new Set([
  "documentation",
  "ui-copy",
  "code",
  "bug",
  "refactor",
  "backend",
  "api",
  "api-auth",
  "complete-website",
  "mobile-ui",
  "web-game",
  "html-video",
  "infrastructure",
  "security-review",
  "performance",
  "accessibility",
  "test-only",
  "dependency-update",
  "release",
]);

const SIGNALS = Object.freeze({
  surfaces: new Set([
    "ui",
    "forms",
    "api",
    "auth",
    "data",
    "database",
    "mobile",
    "desktop",
    "game",
    "video",
    "ci",
    "config",
    "critical-path",
    "documentation",
  ]),
  risks: new Set([
    "untrusted-input",
    "personal-data",
    "secrets",
    "external-service",
    "publication",
    "critical-path",
    "performance",
    "accessibility",
    "destructive",
    "irreversible",
    "production-deployment",
    "credentials",
    "payment",
    "migration",
  ]),
  platforms: new Set(["web", "mobile", "desktop", "server", "ci", "cross-platform"]),
});

const PROJECT_FRAMEWORKS = new Set([
  "flutter", "dotnet", "aspnetcore", "abp", "nodejs", "rust",
  "c", "cpp", "java", "sql", "go", "typescript", "php", "swift",
]);

const LANGUAGE_PROJECT_GUIDES = Object.freeze([
  ["c", "PROJECT_C_CONFIRMED"],
  ["cpp", "PROJECT_CPP_CONFIRMED"],
  ["java", "PROJECT_JAVA_CONFIRMED"],
  ["go", "PROJECT_GO_CONFIRMED"],
  ["typescript", "PROJECT_TYPESCRIPT_CONFIRMED"],
  ["php", "PROJECT_PHP_CONFIRMED"],
  ["swift", "PROJECT_SWIFT_CONFIRMED"],
  ["sql", "PROJECT_SQL_CONFIRMED"],
]);

export const PLATFORM_SEMANTICS = Object.freeze({
  web: Object.freeze({
    mode: "informational-only",
    description: "Web is recorded as context; surface, risk, and work signals select guides.",
  }),
  mobile: Object.freeze({
    mode: "contextual",
    reason: "PLATFORM_MOBILE",
    description: "Mobile UI context adds performance guidance and reinforces design/accessibility.",
  }),
  desktop: Object.freeze({
    mode: "contextual",
    reason: "PLATFORM_DESKTOP",
    description: "Desktop UI context reinforces design and accessibility guidance.",
  }),
  server: Object.freeze({
    mode: "contextual",
    reason: "PLATFORM_SERVER",
    description: "Server authentication context adds testing and reinforces the trust boundary.",
  }),
  ci: Object.freeze({
    mode: "contextual",
    reason: "PLATFORM_CI",
    description: "Executable CI changes add security review to the existing change checks.",
  }),
  "cross-platform": Object.freeze({
    mode: "informational-only",
    description: "Cross-platform is recorded as context; it does not select a guide by itself.",
  }),
});

const WORK_GUIDES = Object.freeze({
  "complete-website": ["premium", "design", "taste", "accessibility", "clean", "test", "security", "performance"],
  "api-auth": ["clean", "test", "security", "performance"],
  api: ["clean", "test"],
  backend: ["clean", "test"],
  code: ["clean", "test"],
  bug: ["clean", "test"],
  refactor: ["clean", "test"],
  "dependency-update": ["clean", "test"],
  release: ["clean", "test"],
  "mobile-ui": ["clean", "test", "design", "accessibility", "security", "performance"],
  "web-game": ["games", "clean", "test", "security", "performance", "accessibility"],
  "html-video": ["design", "accessibility", "performance", "test", "security"],
  infrastructure: ["security", "test"],
  "security-review": ["security"],
  performance: ["performance", "test"],
  accessibility: ["accessibility", "test"],
  "test-only": ["test"],
  documentation: ["documentation"],
  "ui-copy": ["design", "accessibility"],
});

const PRIMARY_GUIDES = Object.freeze({
  "complete-website": "premium",
  "web-game": "games",
  documentation: "documentation",
  "ui-copy": "design",
});

function hasFlutterWorkContext(workType) {
  return !["documentation", "ui-copy"].includes(workType);
}

function addFlutterProjectGuides(input, add) {
  const projectEvidence = input.projectEvidence;
  if (!projectEvidence?.frameworks.includes("flutter")
    || !["MATCH", "UNSCOPED"].includes(projectEvidence.scope)
    || !hasFlutterWorkContext(input.workType)) return;
  add("flutter", "PROJECT_FLUTTER_SDK_DEPENDENCY");
}

function hasDotNetWorkContext(workType) {
  return !["documentation", "ui-copy"].includes(workType);
}

function addDotNetProjectGuides(input, add) {
  const projectEvidence = input.projectEvidence;
  if (!projectEvidence?.frameworks.includes("dotnet")
    || !["MATCH", "UNSCOPED"].includes(projectEvidence.scope)
    || !hasDotNetWorkContext(input.workType)) return;
  add("dotnet", "PROJECT_DOTNET_SDK_PROJECT");
  if (projectEvidence.frameworks.includes("aspnetcore")) add("dotnet", "PROJECT_ASPNETCORE_CONFIRMED");
  if (projectEvidence.frameworks.includes("abp")) add("dotnet", "PROJECT_ABP_CONFIRMED");
}

function hasNodeJsWorkContext(workType) {
  return !["documentation", "ui-copy", "mobile-ui"].includes(workType);
}

function addNodeJsProjectGuides(input, add) {
  const projectEvidence = input.projectEvidence;
  if (!projectEvidence?.frameworks.includes("nodejs")
    || !["MATCH", "UNSCOPED"].includes(projectEvidence.scope)
    || !hasNodeJsWorkContext(input.workType)) return;
  add("nodejs", "PROJECT_NODEJS_CONFIRMED");
  if (projectEvidence.primarySignals.some((signal) => signal.includes(":dependencies.") || signal.includes(":optionalDependencies."))) {
    add("nodejs", "PROJECT_NODEJS_BACKEND_FRAMEWORK");
  }
  if (projectEvidence.primarySignals.some((signal) => signal.includes(":scripts."))) {
    add("nodejs", "PROJECT_NODEJS_RUNTIME_SCRIPT");
  }
  if (projectEvidence.primarySignals.some((signal) => signal.includes(":import="))) {
    add("nodejs", "PROJECT_NODEJS_SERVER_RUNTIME");
  }
}

function hasRustWorkContext(workType) {
  return !["documentation", "ui-copy", "mobile-ui"].includes(workType);
}

function addRustProjectGuides(input, add) {
  const projectEvidence = input.projectEvidence;
  if (!projectEvidence?.frameworks.includes("rust")
    || !["MATCH", "UNSCOPED"].includes(projectEvidence.scope)
    || !hasRustWorkContext(input.workType)) return;
  add("rust", "PROJECT_RUST_CONFIRMED");
  if (projectEvidence.primarySignals.some((signal) => signal.endsWith(":package"))) {
    add("rust", "PROJECT_RUST_CARGO_PACKAGE");
  }
  if (projectEvidence.primarySignals.some((signal) => signal.endsWith(":workspace"))) {
    add("rust", "PROJECT_RUST_CARGO_WORKSPACE");
  }
}

function hasLanguageWorkContext(workType) {
  return !["documentation", "ui-copy"].includes(workType);
}

function addLanguageProjectGuides(input, add) {
  const projectEvidence = input.projectEvidence;
  if (!projectEvidence || !["MATCH", "UNSCOPED"].includes(projectEvidence.scope)
    || !hasLanguageWorkContext(input.workType)) return;
  for (const [guide, reason] of LANGUAGE_PROJECT_GUIDES) {
    if (projectEvidence.frameworks.includes(guide)) add(guide, reason);
  }
}

function addProjectBaselineGuides(input, add) {
  const projectEvidence = input.projectEvidence;
  if (!projectEvidence || !["MATCH", "UNSCOPED"].includes(projectEvidence.scope)) return;
  if (projectEvidence.frameworks.includes("flutter") && hasFlutterWorkContext(input.workType)) {
    add("clean", "PROJECT_FLUTTER_BASELINE");
    add("test", "PROJECT_FLUTTER_BASELINE");
  }
  if (projectEvidence.frameworks.includes("dotnet") && hasDotNetWorkContext(input.workType)) {
    add("clean", "PROJECT_DOTNET_BASELINE");
    add("test", "PROJECT_DOTNET_BASELINE");
  }
  if (projectEvidence.frameworks.includes("nodejs") && hasNodeJsWorkContext(input.workType)) {
    add("clean", "PROJECT_NODEJS_BASELINE");
    add("test", "PROJECT_NODEJS_BASELINE");
  }
  if (projectEvidence.frameworks.includes("rust") && hasRustWorkContext(input.workType)) {
    add("clean", "PROJECT_RUST_BASELINE");
    add("test", "PROJECT_RUST_BASELINE");
  }
  if (hasLanguageWorkContext(input.workType)) {
    for (const [language] of LANGUAGE_PROJECT_GUIDES) {
      if (!projectEvidence.frameworks.includes(language)) continue;
      add("clean", `PROJECT_${language.toUpperCase()}_BASELINE`);
      add("test", `PROJECT_${language.toUpperCase()}_BASELINE`);
    }
  }
}

function flutterExclusionReason(projectEvidence, workType) {
  if (!projectEvidence) return "NO_FLUTTER_PROJECT_EVIDENCE";
  if (projectEvidence.scope === "NO_MATCH") return "NO_FLUTTER_SCOPE_MATCH";
  if (!projectEvidence.frameworks.includes("flutter")) return "NO_FLUTTER_PRIMARY_EVIDENCE";
  if (!hasFlutterWorkContext(workType)) return "NO_FLUTTER_EXECUTABLE_WORK";
  return "NO_FLUTTER_PRIMARY_EVIDENCE";
}

function dotNetExclusionReason(projectEvidence, workType) {
  if (!projectEvidence) return "NO_DOTNET_PROJECT_EVIDENCE";
  if (projectEvidence.scope === "NO_MATCH") return "NO_DOTNET_SCOPE_MATCH";
  if (!projectEvidence.frameworks.includes("dotnet")) return "NO_DOTNET_PRIMARY_EVIDENCE";
  if (!hasDotNetWorkContext(workType)) return "NO_DOTNET_EXECUTABLE_WORK";
  return "NO_DOTNET_PRIMARY_EVIDENCE";
}

function nodeJsExclusionReason(projectEvidence, workType) {
  if (!projectEvidence) return "NO_NODEJS_PROJECT_EVIDENCE";
  if (projectEvidence.scope === "NO_MATCH") return "NO_NODEJS_SCOPE_MATCH";
  if (!projectEvidence.frameworks.includes("nodejs")) return "NO_NODEJS_PRIMARY_EVIDENCE";
  if (!hasNodeJsWorkContext(workType)) return "NO_NODEJS_EXECUTABLE_WORK";
  return "NO_NODEJS_PRIMARY_EVIDENCE";
}

function rustExclusionReason(projectEvidence, workType) {
  if (!projectEvidence) return "NO_RUST_PROJECT_EVIDENCE";
  if (projectEvidence.scope === "NO_MATCH") return "NO_RUST_SCOPE_MATCH";
  if (!projectEvidence.frameworks.includes("rust")) return "NO_RUST_PRIMARY_EVIDENCE";
  if (!hasRustWorkContext(workType)) return "NO_RUST_EXECUTABLE_WORK";
  return "NO_RUST_PRIMARY_EVIDENCE";
}

function exclusionReasonForGuide(guide, projectEvidence, workType) {
  if (guide === "security") return "NO_TRUST_BOUNDARY";
  if (guide === "performance") return "NO_MEASURABLE_PERFORMANCE_RISK";
  if (guide === "design" || guide === "accessibility") return "NO_UI_SURFACE";
  if (guide === "premium" || guide === "games") return "NO_PRIMARY_WORK_TYPE";
  if (guide === "taste") return "NO_TASTE_FRONTEND_CONTEXT";
  if (guide === "documentation") return "NO_DOCUMENTATION_SURFACE";
  if (guide === "flutter") return flutterExclusionReason(projectEvidence, workType);
  if (guide === "dotnet") return dotNetExclusionReason(projectEvidence, workType);
  if (guide === "nodejs") return nodeJsExclusionReason(projectEvidence, workType);
  if (guide === "rust") return rustExclusionReason(projectEvidence, workType);
  if (LANGUAGE_PROJECT_GUIDES.some(([language]) => language === guide)) {
    if (!projectEvidence) return `NO_${guide.toUpperCase()}_PROJECT_EVIDENCE`;
    if (projectEvidence.scope === "NO_MATCH") return `NO_${guide.toUpperCase()}_SCOPE_MATCH`;
    if (!projectEvidence.frameworks.includes(guide)) return `NO_${guide.toUpperCase()}_PRIMARY_EVIDENCE`;
    if (!hasLanguageWorkContext(workType)) return `NO_${guide.toUpperCase()}_EXECUTABLE_WORK`;
    return `NO_${guide.toUpperCase()}_PRIMARY_EVIDENCE`;
  }
  return "NO_BEHAVIOR_OR_EXECUTABLE_CHANGE";
}

export class RouteInputError extends Error {
  constructor(message) {
    super(message);
    this.name = "RouteInputError";
    this.code = "ROUTING_FAILURE";
  }
}

function reasonForWorkType(workType) {
  return `WORK_${workType.toUpperCase().replaceAll("-", "_")}`;
}

function reasonForSignal(prefix, signal) {
  return `${prefix}_${signal.toUpperCase().replaceAll("-", "_")}`;
}

function normalizeArray(value, name, allowed) {
  if (value === undefined) return [];
  if (!Array.isArray(value)) throw new RouteInputError(`${name} must be an array`);
  const seen = new Set();
  for (const item of value) {
    if (typeof item !== "string" || !allowed.has(item)) {
      throw new RouteInputError(`Unknown ${name.slice(0, -1)}: ${item}`);
    }
    if (seen.has(item)) throw new RouteInputError(`Duplicate ${name.slice(0, -1)}: ${item}`);
    seen.add(item);
  }
  return [...seen].sort();
}

function normalizeStringList(value, name) {
  if (value === undefined) return [];
  if (!Array.isArray(value)) throw new RouteInputError(`${name} must be an array`);
  const seen = new Set();
  for (const item of value) {
    if (typeof item !== "string" || item.trim() === "") {
      throw new RouteInputError(`${name} must contain non-empty strings`);
    }
    if (seen.has(item)) throw new RouteInputError(`Duplicate ${name.slice(0, -1)}: ${item}`);
    seen.add(item);
  }
  return [...seen].sort();
}

function normalizeProjectEvidence(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new RouteInputError("projectEvidence must be an object");
  }
  if (value.schemaVersion !== undefined && value.schemaVersion !== ROUTING_SCHEMA_VERSION) {
    throw new RouteInputError(`Unsupported projectEvidence schema version: ${value.schemaVersion}`);
  }
  const frameworks = normalizeArray(value.frameworks, "frameworks", PROJECT_FRAMEWORKS);
  const hasDotnet = frameworks.includes("dotnet");
  const invalidOverlays = frameworks.filter((framework) => framework === "aspnetcore" || framework === "abp");
  if (!hasDotnet && invalidOverlays.length > 0) {
    const noun = invalidOverlays.length === 1 ? "framework" : "frameworks";
    const verb = invalidOverlays.length === 1 ? "requires" : "require";
    const labels = invalidOverlays.map((framework) => `"${framework}"`).join(", ");
    throw new RouteInputError(`projectEvidence ${noun} ${labels} ${verb} "dotnet"`);
  }
  const scope = value.scope ?? (frameworks.length > 0 ? "UNSCOPED" : "NONE");
  if (!PROJECT_EVIDENCE_SCOPES.includes(scope)) {
    throw new RouteInputError(`Unknown project evidence scope: ${scope}`);
  }
  return {
    schemaVersion: ROUTING_SCHEMA_VERSION,
    scope,
    frameworks,
    projectRoots: normalizeStringList(value.projectRoots, "projectRoots"),
    primarySignals: normalizeStringList(value.primarySignals, "primarySignals"),
    supportingSignals: normalizeStringList(value.supportingSignals, "supportingSignals"),
  };
}

export function normalizeRouteInput(input = {}) {
  if (!input || typeof input !== "object" || Array.isArray(input)) {
    throw new RouteInputError("Route input must be an object");
  }
  if (typeof input.workType !== "string" || !WORK_TYPES.has(input.workType)) {
    throw new RouteInputError(`Unknown work type: ${input.workType}`);
  }
  for (const key of ["behaviorChange", "executableChange"]) {
    if (input[key] !== undefined && typeof input[key] !== "boolean") {
      throw new RouteInputError(`${key} must be boolean`);
    }
  }
  const projectEvidence = input.projectEvidence === undefined
    ? undefined
    : normalizeProjectEvidence(input.projectEvidence);
  return {
    schemaVersion: ROUTING_SCHEMA_VERSION,
    workType: input.workType,
    surfaces: normalizeArray(input.surfaces, "surfaces", SIGNALS.surfaces),
    risks: normalizeArray(input.risks, "risks", SIGNALS.risks),
    platforms: normalizeArray(input.platforms, "platforms", SIGNALS.platforms),
    behaviorChange: input.behaviorChange ?? false,
    executableChange: input.executableChange ?? false,
    ...(projectEvidence ? { projectEvidence } : {}),
  };
}

export function evaluateRoute(input = {}, profileOptions = {}) {
  const normalized = normalizeRouteInput(input);
  const selected = new Map();
  const excluded = {};

  function add(guide, reason) {
    if (!GUIDE_IDS.includes(guide)) throw new RouteInputError(`Unknown guide: ${guide}`);
    const reasons = selected.get(guide) ?? [];
    if (!reasons.includes(reason)) reasons.push(reason);
    selected.set(guide, reasons);
  }

  const projectEvidence = normalized.projectEvidence;
  addFlutterProjectGuides(normalized, add);
  addDotNetProjectGuides(normalized, add);
  addNodeJsProjectGuides(normalized, add);
  addRustProjectGuides(normalized, add);
  addLanguageProjectGuides(normalized, add);
  addProjectBaselineGuides(normalized, add);

  const workReason = reasonForWorkType(normalized.workType);
  for (const guide of WORK_GUIDES[normalized.workType]) add(guide, workReason);

  if (normalized.surfaces.includes("ui") || normalized.surfaces.includes("forms")) {
    add("design", "SURFACE_UI");
    add("accessibility", normalized.surfaces.includes("forms") ? "SURFACE_FORMS" : "SURFACE_UI");
  }
  if (normalized.surfaces.includes("mobile") || normalized.surfaces.includes("desktop")) {
    add("design", "SURFACE_PLATFORM_UI");
    add("accessibility", "SURFACE_PLATFORM_UI");
  }
  if (normalized.surfaces.includes("game")) add("games", "SURFACE_GAME");
  if (normalized.surfaces.includes("video")) {
    add("design", "SURFACE_VIDEO");
    add("accessibility", "SURFACE_VIDEO");
  }
  if (normalized.surfaces.includes("auth")) add("security", "SURFACE_AUTH");
  if (normalized.surfaces.includes("documentation")) {
    add("documentation", "SURFACE_DOCUMENTATION");
  }

  for (const risk of normalized.risks) {
    if (["untrusted-input", "personal-data", "secrets", "external-service", "publication"].includes(risk)) {
      add("security", reasonForSignal("RISK", risk));
    }
    if (["critical-path", "performance"].includes(risk)) {
      add("performance", reasonForSignal("RISK", risk));
    }
    if (risk === "accessibility") add("accessibility", "RISK_ACCESSIBILITY");
  }

  if (normalized.behaviorChange) {
    add("clean", "CHANGE_BEHAVIOR");
    add("test", "CHANGE_BEHAVIOR");
  }
  if (normalized.executableChange) {
    add("clean", "CHANGE_EXECUTABLE_CONFIG");
    add("test", "CHANGE_EXECUTABLE_CONFIG");
  }

  const hasUiContext = normalized.surfaces.some((surface) => ["ui", "forms", "mobile", "desktop"].includes(surface));
  if (normalized.platforms.includes("mobile") && hasUiContext) {
    add("design", "PLATFORM_MOBILE");
    add("accessibility", "PLATFORM_MOBILE");
    add("performance", "PLATFORM_MOBILE");
  }
  if (normalized.platforms.includes("desktop") && hasUiContext) {
    add("design", "PLATFORM_DESKTOP");
    add("accessibility", "PLATFORM_DESKTOP");
  }
  if (normalized.platforms.includes("server") && normalized.surfaces.includes("auth")) {
    add("security", "PLATFORM_SERVER");
    add("test", "PLATFORM_SERVER");
  }
  if (normalized.platforms.includes("ci") && normalized.executableChange) {
    add("security", "PLATFORM_CI");
  }

  for (const guide of GUIDE_IDS) {
    if (selected.has(guide)) continue;
    excluded[guide] = [exclusionReasonForGuide(guide, projectEvidence, normalized.workType)];
  }

  const guides = [...selected.keys()];
  const result = {
    schemaVersion: ROUTING_SCHEMA_VERSION,
    protocolVersion: PROTOCOL_VERSION,
    input: normalized,
    primary: Object.prototype.hasOwnProperty.call(PRIMARY_GUIDES, normalized.workType)
      ? PRIMARY_GUIDES[normalized.workType]
      : guides[0] ?? null,
    guides,
    reasons: Object.fromEntries(guides.map((guide) => [guide, selected.get(guide)])),
    excluded,
    executionProfile: resolveExecutionProfile({
      routeInput: normalized,
      contract: profileOptions.contract ?? input.contract ?? null,
      taskDescriptor: profileOptions.taskDescriptor ?? input.taskDescriptor ?? null,
      configuredProfile: profileOptions.configuredProfile ?? input.configuredProfile ?? "auto",
      requestedProfile: profileOptions.requestedProfile
        ?? (Object.prototype.hasOwnProperty.call(input, "executionProfile") ? input.executionProfile : null),
    }),
  };
  return assertRouteInvariants(result);
}

export function assertRouteInvariants(result) {
  const invariantError = (code, message) => {
    const error = new RouteInputError(message);
    error.code = code;
    return error;
  };
  if (!result || typeof result !== "object" || Array.isArray(result)) {
    throw invariantError("E_ROUTE_INVALID", "Route result must be an object");
  }
  if (!Array.isArray(result.guides) || new Set(result.guides).size !== result.guides.length) {
    throw invariantError("E_ROUTE_INVALID", "Route result contains duplicate guides");
  }
  if (result.contractFingerprint !== undefined && !/^[a-f0-9]{64}$/.test(result.contractFingerprint)) {
    throw invariantError("E_ROUTE_INVALID", "Route contractFingerprint must be a lowercase SHA-256 fingerprint");
  }
  if (result.executionProfile !== undefined) {
    try {
      assertExecutionProfile(result.executionProfile);
    } catch (error) {
      throw invariantError(error.code ?? "E_EXECUTION_PROFILE_INCONSISTENT", error.message);
    }
  }
  for (const guide of result.guides) {
    if (!GUIDE_IDS.includes(guide)) throw invariantError("E_ROUTE_INVALID", `Route result contains unknown guide: ${guide}`);
    if (!Array.isArray(result.reasons?.[guide]) || result.reasons[guide].length === 0) {
      throw invariantError("E_ROUTE_REASON_MISSING", `Selected guide has no reason: ${guide}`);
    }
  }
  for (const [guide, reasons] of Object.entries(result.excluded ?? {})) {
    if (!GUIDE_IDS.includes(guide)) {
      throw invariantError("E_ROUTE_INVALID", `Route result contains unknown excluded guide: ${guide}`);
    }
    if (result.guides.includes(guide)) {
      throw invariantError("E_ROUTE_INVALID", `Guide cannot be selected and excluded: ${guide}`);
    }
    if (!Array.isArray(reasons) || reasons.length === 0) {
      throw invariantError("E_ROUTE_REASON_MISSING", `Excluded guide has no exclusion reason: ${guide}`);
    }
  }
  if (result.primary !== null && !result.guides.includes(result.primary)) {
    throw invariantError("E_ROUTE_INVALID", "Primary guide must be null or selected");
  }
  return result;
}

export const ROUTING_SIGNALS = Object.freeze({
  workTypes: Object.freeze([...WORK_TYPES].sort()),
  surfaces: Object.freeze([...SIGNALS.surfaces].sort()),
  risks: Object.freeze([...SIGNALS.risks].sort()),
  platforms: Object.freeze([...SIGNALS.platforms].sort()),
});
